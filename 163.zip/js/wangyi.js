
//************页头******************
var aa = document.querySelectorAll(".class_list>a");
for(var i=0;i<aa.length;i++){
	aa[i].onmouseover = function(){
		this.querySelectorAll("b")[0].style.width='100%';
	}
}for(var i=0;i<aa.length;i++){
	aa[i].onmouseout = function(){
		this.querySelectorAll("b")[0].style.width='0';
	}
}

$(".top_open").click(function(){
        var temp=0;
        function change(){
            if(temp==0){
                $(".top_open").css('background','#282b2d').css('height','100px');
                $(".top_open i").css('background-position','-34px 0');
                $("#top .topNav").slideDown(800);
                temp=1;
            }else if(temp==1){
 
                 $(".top_open").css('background','#cf1132').css('height','120px');
                $(".top_open i").css('background-position','-68px 0');
                 $("#top .topNav").slideUp(800);
                temp=0;
            }
        }
        return change;
}());
//**************动画轮播*****************************
var div=$('#d>div');
var tips=$('#nav>.button>i');
var n=0;
function change(){
    for(var i=0;i<div.length;i++){
        div[i].style.opacity=0;
    }
    tips.css('background','#fff');
    if(n==div.length-1){
        n=0;
    }else{
        n++;
    }
    div[n].style.opacity=1;
    tips[n].style.backgroundColor="red";
}
function changeleft(){
    for(var i=div.length-1;i>0;i--){
        div[i].style.opacity=0;
    }
    tips.css('background','#fff');
    if(n==0){
        n=div.length-1;
    }else{
        n--;
    }
    div[n].style.opacity=1;
    tips[n].style.backgroundColor="red";
}
var timer=setInterval(change,4000);
$('#nav .button i').mouseover(function(){
    var index=$(this).index();
    n=index-1;
    change();
})
$('#nav').mouseenter(function(){
	clearInterval(timer);
})
$('#nav').mouseleave(function(){
	timer=setInterval(change,4000);
})
$('#topClose').click(function(){
	$('#top .topNav').slideUp(800);
	$(".top_open").css('background','#cf1132').css('height','120px');
    $(".top_open i").css('background-position','-68px 0');
	return false;
})
$('.head-right').click(function(){
	change();
	return false;
})
$('.head-left').click(function(){
	//n-=2;
	changeleft();
	return false;
})
var temp=0;
$("#container .changeleft").click(function(){
    $(this).css('background-position','-47px -20px');
    $("#container .changeright").css('background-position','-37px -20px');
	$("#container .middle-1").css('left','0');
	$("#container .middle-2").css('left','100%');
	
	return false;
})
$("#container .changeright").click(function(){
    $(this).css('background-position','-47px -20px');
    $("#container .changeleft").css('background-position','-37px -20px');
	$("#container .middle-2").css('left','0');
	$("#container .middle-1").css('left','-100%');	
	
	return false;	
})


$('.middle .middle-1-left').mouseenter(function(){
    $(this).find('.middle-1-left-img').css('background-position','64% 50%');
})
$('.middle .middle-1-left').mouseleave(function(){
    $(this).find('.middle-1-left-img').css('background-position','40% 50%');
})
$('.middle .middle-1-right').mouseenter(function(){
    $(this).find('.middle-1-right-img').css('background-position','64% 50%');
})
$('.middle .middle-1-right').mouseleave(function(){
    $(this).find('.middle-1-right-img').css('background-position','40% 50%');
})
$('.middle .middle-2-left').mouseenter(function(){
    $(this).find('.middle-2-left-img').css('background-position','64% 50%');
})
$('.middle .middle-2-left').mouseleave(function(){
    $(this).find('.middle-2-left-img').css('background-position','40% 50%');
})
$('.middle .middle-2-right').mouseenter(function(){
    $(this).find('.middle-2-right-img').css('background-position','64% 50%');
})
$('.middle .middle-2-right').mouseleave(function(){
    $(this).find('.middle-2-right-img').css('background-position','40% 50%');
})

// ***************************热点广告************************************************
$('.hotBox a.hot-foot').mouseenter(function(){
    $(this).css('bottom','14px');
    var newThis=this;
    setTimeout(function(){
        $(newThis).css('bottom','20px');
    },300)
})

//********点击切换下一批*******
var add=0;
var divs=$('#hotWords .hotWords-img>div');
var pre = 4;
$('#hotWords .hotWords-top-tittle a').click(function(e){
    e.preventDefault();
    add++;
    if(add>divs.length-1){
        add=0;
    }
    if(add == 0){
        pre = divs.length-1;
    }else{
        pre = add -1;
    }
	//console.log(divs);
    //console.log(add,pre)
	//console.log(divs[pre]);
    divs[pre].setAttribute('class','hotWords-img-1');
    
    var div_childs = divs[pre].querySelectorAll("#hotWords div.hotBox");
    div_childs[0].setAttribute('class','hotBox');
    setTimeout(function(){
           div_childs[1].setAttribute('class','hotBox');
    },50)
    setTimeout(function(){
        div_childs[2].setAttribute('class','hotBox');   
    },300)
    divs[add].setAttribute('class','hotWords-img-1 cur');
    setTimeout(function(){
        divs[add].setAttribute('class','hotWords-img-1 cur');
        var div_child = divs[add].querySelectorAll("#hotWords div.hotBox");
        div_child[0].setAttribute('class','hotBox active');
        setTimeout(function(){
            div_child[1].setAttribute('class','hotBox active');
        },50)
        setTimeout(function(){
            div_child[2].setAttribute('class','hotBox active');   
        },300)
    },700)
    
})
//*******点赞功能*********
var add1=0;
 var span=$('.hotBox>span');
 //console.log(span);
 span.click(function(e){
     e.preventDefault();
     var num = parseInt($(this).find('b').html());
     num++;
     
     var spamn = document.createElement("span");
     add1++;
     if(add1>20){spamn.innerHTML="一天只能点赞20次哦"}
        else{spamn.innerHTML = "+1";
        $(this).find('b').html(num);
    }
     $(spamn).addClass("zan");
    $(this).find('a').append(spamn);
    var newThis = this;
    setTimeout(function(){   
        $(spamn).addClass("cur");
    },10)
    setTimeout(function(){   
        $(spamn).addClass("curs");
    },990)
    setTimeout(function(){
        $(spamn).remove();
    },1500)
 })
var add2=0;
 var a=$('.middle p .p1')
    a.click(function(e){
        e.preventDefault();
        var num=parseInt($(this).find('b').html());
        num++;       
        var spamn = document.createElement("i");
        add2++;
        if(add2>20){spamn.innerHTML="一天只能点赞20次哦"}
        else{spamn.innerHTML = "+1";
            $(this).find('b').html(num);
        }
        $(spamn).addClass("zan");
        console.log(spamn);
        $(this).find('a').append(spamn);
        setTimeout(function(){   
            $(spamn).addClass("cur");
        },10)
        setTimeout(function(){   
            $(spamn).addClass("curs");
        },990)
        setTimeout(function(){
         $(spamn).remove();
        },1500)
})
$('#foot-lovegame a').mouseenter(function(){
	$(this).find('.font1').css('top','100%');
	$(this).find('.font2').css('bottom','0');
	$(this).find('span').css('top','75%');
})
$('#foot-lovegame a').mouseleave(function(){
	$(this).find('.font1').css('top','0');
	$(this).find('.font2').css('bottom','-50%');
	$(this).find('span').css('top','50%');
})
//**********************热点手游动画*************************
		//*****切换下一批*******
var adds=0;
var divss="";
var pres = 4;
$('#hotGames .hotWords-top-tittle a.ac').click(function(e){
    e.preventDefault();
    var classes=$('#hotGames .hotGames2').css('display');
    if(classes=='none'){
        divss=$('#hotGames .hotGames1 .hotWords-img>div');
    }
    else{
        //divss="";
        divss=$('#hotGames .hotGames2 .hotWords-img>div');
    }
    adds++;
    if(adds>divss.length-1){
        adds=0;
    }
    if(adds == 0){
        pres = divss.length-1;
    }else{
        pres = adds -1;
    }
	//console.log(divs);
   // console.log(adds,pres)
	//console.log(divs[pre]);
    divss[pres].setAttribute('class','hotWords-img-1');
    
    var div_childs = divss[pres].querySelectorAll("#hotGames div.hotBox");
    div_childs[0].setAttribute('class','hotBox');
    setTimeout(function(){
           div_childs[1].setAttribute('class','hotBox');
    },50)
    setTimeout(function(){
        div_childs[2].setAttribute('class','hotBox');   
    },300)
    divss[adds].setAttribute('class','hotWords-img-1 cur');
    setTimeout(function(){
        divss[adds].setAttribute('class','hotWords-img-1 cur');
        var div_child = divss[adds].querySelectorAll("#hotGames div.hotBox");
        div_child[0].setAttribute('class','hotBox active');
        setTimeout(function(){
            div_child[1].setAttribute('class','hotBox active');
        },50)
        setTimeout(function(){
            div_child[2].setAttribute('class','hotBox active');   
        },300)
    },1000)  
})
		//*****游戏视频和玩家热议*******
$('#foot-games .a1').click(function(e){
	e.preventDefault();
	$(this).siblings('.a1.cur').removeClass('cur');
	$(this).addClass('cur');
})
$('#A2').click(function(e){
	e.preventDefault();
    $('#foot-games .hotGames2').css('display','block');
    $('#foot-games .hotGames1').css('display','none');
})
$('#A1').click(function(e){
	e.preventDefault();
    $('#foot-games .hotGames2').css('display','none');
	$('#foot-games .hotGames1').css('display','block');
    
})
//******************** 底部广告框效果******************
$('#foot-box a').mouseenter(function(){
    $(this).find('.txt1').css('color','#fff');
    $(this).find('.txt2').css('color','#fff');
})
$('#foot-box a').mouseleave(function(){
    $(this).find('.txt1').css('color','#222');
    $(this).find('.txt2').css('color','#222');
})